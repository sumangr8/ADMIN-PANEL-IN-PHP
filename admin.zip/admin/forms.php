<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Bootflat-Admin Template</title>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="shortcut icon" href="favicon_16.ico"/>
    <link rel="bookmark" href="favicon_16.ico"/>
    <!-- site css -->
    <link rel="stylesheet" href="dist/css/site.min.css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,800,700,400italic,600italic,700italic,800italic,300italic" rel="stylesheet" type="text/css">
    <!-- <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'> -->
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript" src="dist/js/site.min.js"></script>
  </head>
  <body>
    <!--nav-->
    <nav role="navigation" class="navbar navbar-custom">
        <div class="container-fluid">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button data-target="#bs-content-row-navbar-collapse-5" data-toggle="collapse" class="navbar-toggle" type="button">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a href="#" class="navbar-brand">Bootflat-Admin</a>
          </div>

          <!-- Collect the nav links, forms, and other content for toggling -->
          <div id="bs-content-row-navbar-collapse-5" class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
              <li class="active"><a href="getting-started.php">Getting Started</a></li>
              <li class="active"><a href="index.php">Documentation</a></li>
              <!-- <li class="disabled"><a href="#">Link</a></li> -->
              <li class="dropdown">
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">Silverbux <b class="caret"></b></a>
                <ul role="menu" class="dropdown-menu">
                  <li class="dropdown-header">Setting</li>
                  <li><a href="#">Action</a></li>
                  <li class="divider"></li>
                  <li class="active"><a href="#">Separated link</a></li>
                  <li class="divider"></li>
                  <li class="disabled"><a href="#">Signout</a></li>
                </ul>
              </li>
            </ul>

          </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
      </nav>
    <!--header-->
    <div class="container-fluid">
    <!--documents-->
        <div class="row row-offcanvas row-offcanvas-left">
          <div class="col-xs-6 col-sm-3 sidebar-offcanvas" role="navigation">
            <ul class="list-group panel">
                <li class="list-group-item"><i class="glyphicon glyphicon-align-justify"></i> <b>SIDE PANEL</b></li>
                <li class="list-group-item"><input type="text" class="form-control search-query" placeholder="Search Something"></li>
                <li class="list-group-item"><a href="index.php"><i class="glyphicon glyphicon-home"></i>Dashboard </a></li>
                <li class="list-group-item"><a href="icons.php"><i class="glyphicon glyphicon-certificate"></i>Icons </a></li>
                <li class="list-group-item"><a href="list.php"><i class="glyphicon glyphicon-th-list"></i>Tables and List </a></li>
                <li class="list-group-item"><a href="forms.php"><i class="glyphicon glyphicon-list-alt"></i>Forms</a></li>
                <li class="list-group-item"><a href="alerts.php"><i class="glyphicon glyphicon-bell"></i>Alerts</li>
                <li class="list-group-item"><a href="timeline.php" ><i class="glyphicon glyphicon-indent-left"></i>Timeline</a></li>
                <li class="list-group-item"><a href="calendars.php" ><i class="glyphicon glyphicon-calendar"></i>Calendars</a></li>
                <li class="list-group-item"><a href="typography.php" ><i class="glyphicon glyphicon-font"></i>Typography</a></li>
                <li class="list-group-item"><a href="footers.php" ><i class="glyphicon glyphicon-minus"></i>Footers</a></li>
                <li class="list-group-item"><a href="panels.php" ><i class="glyphicon glyphicon-list-alt"></i>Panels</a></li>
                <li class="list-group-item"><a href="navs.php" ><i class="glyphicon glyphicon-th-list"></i>Navs</a></li>
                <li class="list-group-item"><a href="colors.php" ><i class="glyphicon glyphicon-tint"></i>Colors</a></li>
                <li class="list-group-item"><a href="flex.php" ><i class="glyphicon glyphicon-th"></i>Flex</a></li>
                <li class="list-group-item"><a href="login.php" ><i class="glyphicon glyphicon-lock"></i>Login</a></li>
                <li>
                  <a href="#demo3" class="list-group-item " data-toggle="collapse">Item 3  <span class="glyphicon glyphicon-chevron-right"></span></a>
                  <div class="collapse" id="demo3">
                    <a href="#SubMenu1" class="list-group-item" data-toggle="collapse">Subitem 1  <span class="glyphicon glyphicon-chevron-right"></span></a>
                    <div class="collapse list-group-submenu" id="SubMenu1">
                      <a href="#" class="list-group-item">Subitem 1 a</a>
                      <a href="#" class="list-group-item">Subitem 2 b</a>
                      <a href="#SubSubMenu1" class="list-group-item" data-toggle="collapse">Subitem 3 c <span class="glyphicon glyphicon-chevron-right"></span></a>
                      <div class="collapse list-group-submenu list-group-submenu-1" id="SubSubMenu1">
                        <a href="#" class="list-group-item">Sub sub item 1</a>
                        <a href="#" class="list-group-item">Sub sub item 2</a>
                      </div>
                      <a href="#" class="list-group-item">Subitem 4 d</a>
                    </div>
                    <a href="javascript:;" class="list-group-item">Subitem 2</a>
                    <a href="javascript:;" class="list-group-item">Subitem 3</a>
                  </div>
                </li>
                <li>
                  <a href="#demo4" class="list-group-item " data-toggle="collapse">Item 4  <span class="glyphicon glyphicon-chevron-right"></span></a>
                    <li class="collapse" id="demo4">
                      <a href="" class="list-group-item">Subitem 1</a>
                      <a href="" class="list-group-item">Subitem 2</a>
                      <a href="" class="list-group-item">Subitem 3</a>
                    </li>
                </li>
              </ul>
          </div>
          <div class="col-xs-12 col-sm-9 content">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar"><span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span></a> Panel Title</h3>
              </div>
                            <div class="panel-body">
                <div class="content-row">
                  <h2 class="content-row-title">Buttons</h2>
                  <div class="row">
                    <div class="col-md-3">
                      <button type="button" class="btn btn-block">Normal</button>
                    </div>
                    <div class="col-md-3">
                      <button type="button" class="btn btn-default btn-block">Default</button>
                    </div>
                    <div class="col-md-3">
                      <button type="button" class="btn btn-primary btn-block">Primary</button>
                    </div>
                    <div class="col-md-3">
                      <button type="button" class="btn btn-success btn-block">Success</button>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-3">
                      <button type="button" class="btn btn-info btn-block">Info</button>
                    </div>
                    <div class="col-md-3">
                      <button type="button" class="btn btn-warning btn-block">Warning</button>
                    </div>
                    <div class="col-md-3">
                      <button type="button" class="btn btn-danger btn-block">Danger</button>
                    </div>
                    <div class="col-md-3">
                      <button type="button" class="btn btn-link btn-block">Link</button>
                    </div>
                  </div>
                </div>

                <div class="content-row">
                  <h2 class="content-row-title">Button Groups</h2>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="row">
                        <div class="col-md-4">
                          <div class="btn-group">
                            <button type="button" class="btn"><i class="glyphicon glyphicon-align-left"></i></button>
                            <button type="button" class="btn"><i class="glyphicon glyphicon-align-center"></i></button>
                            <button type="button" class="btn"><i class="glyphicon glyphicon-align-right"></i></button>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="btn-group">
                            <button type="button" class="btn btn-default"><i class="glyphicon glyphicon-align-left"></i></button>
                            <button type="button" class="btn btn-default"><i class="glyphicon glyphicon-align-center"></i></button>
                            <button type="button" class="btn btn-default"><i class="glyphicon glyphicon-align-right"></i></button>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="btn-group">
                            <button type="button" class="btn btn-primary"><i class="glyphicon glyphicon-align-left"></i></button>
                            <button type="button" class="btn btn-primary"><i class="glyphicon glyphicon-align-center"></i></button>
                            <button type="button" class="btn btn-primary"><i class="glyphicon glyphicon-align-right"></i></button>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-4">
                          <div class="btn-group">
                            <button type="button" class="btn btn-success"><i class="glyphicon glyphicon-align-left"></i></button>
                            <button type="button" class="btn btn-success"><i class="glyphicon glyphicon-align-center"></i></button>
                            <button type="button" class="btn btn-success"><i class="glyphicon glyphicon-align-right"></i></button>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="btn-group">
                            <button type="button" class="btn btn-info"><i class="glyphicon glyphicon-align-left"></i></button>
                            <button type="button" class="btn btn-info"><i class="glyphicon glyphicon-align-center"></i></button>
                            <button type="button" class="btn btn-info"><i class="glyphicon glyphicon-align-right"></i></button>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="btn-group">
                            <button type="button" class="btn btn-warning"><i class="glyphicon glyphicon-align-left"></i></button>
                            <button type="button" class="btn btn-warning"><i class="glyphicon glyphicon-align-center"></i></button>
                            <button type="button" class="btn btn-warning"><i class="glyphicon glyphicon-align-right"></i></button>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="btn-group">
                            <button type="button" class="btn btn-danger"><i class="glyphicon glyphicon-align-left"></i></button>
                            <button type="button" class="btn btn-danger"><i class="glyphicon glyphicon-align-center"></i></button>
                            <button type="button" class="btn btn-danger"><i class="glyphicon glyphicon-align-right"></i></button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="row">
                        <div class="col-md-2">
                          <div class="btn-group-vertical">
                            <button type="button" class="btn btn"><i class="glyphicon glyphicon-home"></i></button>
                            <button type="button" class="btn btn"><i class="glyphicon glyphicon-user"></i></button>
                            <button type="button" class="btn btn"><i class="glyphicon glyphicon-comment"></i></button>
                            <button type="button" class="btn btn"><i class="glyphicon glyphicon-cog"></i></button>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="btn-group-vertical">
                            <button type="button" class="btn btn-default"><i class="glyphicon glyphicon-home"></i></button>
                            <button type="button" class="btn btn-default"><i class="glyphicon glyphicon-user"></i></button>
                            <button type="button" class="btn btn-default"><i class="glyphicon glyphicon-comment"></i></button>
                            <button type="button" class="btn btn-default"><i class="glyphicon glyphicon-cog"></i></button>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="btn-group-vertical">
                            <button type="button" class="btn btn-primary"><i class="glyphicon glyphicon-home"></i></button>
                            <button type="button" class="btn btn-primary"><i class="glyphicon glyphicon-user"></i></button>
                            <button type="button" class="btn btn-primary"><i class="glyphicon glyphicon-comment"></i></button>
                            <button type="button" class="btn btn-primary"><i class="glyphicon glyphicon-cog"></i></button>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="btn-group-vertical">
                            <button type="button" class="btn btn-success"><i class="glyphicon glyphicon-home"></i></button>
                            <button type="button" class="btn btn-success"><i class="glyphicon glyphicon-user"></i></button>
                            <button type="button" class="btn btn-success"><i class="glyphicon glyphicon-comment"></i></button>
                            <button type="button" class="btn btn-success"><i class="glyphicon glyphicon-cog"></i></button>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="btn-group-vertical">
                            <button type="button" class="btn btn-info"><i class="glyphicon glyphicon-home"></i></button>
                            <button type="button" class="btn btn-info"><i class="glyphicon glyphicon-user"></i></button>
                            <button type="button" class="btn btn-info"><i class="glyphicon glyphicon-comment"></i></button>
                            <button type="button" class="btn btn-info"><i class="glyphicon glyphicon-cog"></i></button>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="btn-group-vertical">
                            <button type="button" class="btn btn-danger"><i class="glyphicon glyphicon-home"></i></button>
                            <button type="button" class="btn btn-danger"><i class="glyphicon glyphicon-user"></i></button>
                            <button type="button" class="btn btn-danger"><i class="glyphicon glyphicon-comment"></i></button>
                            <button type="button" class="btn btn-danger"><i class="glyphicon glyphicon-cog"></i></button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="content-row">
                  <h2 class="content-row-title">Button Dropdowns</h2>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="btn-group">
                        <button type="button" class="btn dropdown-toggle" data-toggle="dropdown">Normal <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">Default <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Primary <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">Success <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">Info <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">Warning <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">Danger <span class="caret"></span></button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="btn-group">
                        <button type="button" class="btn">Normal</button>
                        <button type="button" class="btn dropdown-toggle" data-toggle="dropdown">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                              </button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-default">Default</button>
                        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                              </button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-primary">Primary</button>
                        <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                              </button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-success">Success</button>
                        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                              </button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-info">Info</button>
                        <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                              </button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-warning">Warning</button>
                        <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                              </button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                      <div class="blank"></div>
                      <div class="btn-group">
                        <button type="button" class="btn btn-danger">Danger</button>
                        <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                              </button>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Action</a></li>
                          <li><a href="#">Another action</a></li>
                          <li><a href="#">Something else here</a></li>
                          <li class="divider"></li>
                          <li><a href="#">Separated link</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="content-row">
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <div class="panel-title"><b>Height sizing</b>
                      </div>

                      <div class="panel-options">
                        <a class="bg" data-target="#sample-modal-dialog-1" data-toggle="modal" href="#sample-modal"><i class="entypo-cog"></i></a>
                        <a data-rel="collapse" href="#"><i class="entypo-down-open"></i></a>
                        <a data-rel="close" href="#!/tasks" ui-sref="Tasks"><i class="entypo-cancel"></i></a>
                      </div>
                    </div>

                    <div class="panel-body">
                      <form role="form">
                        <div class="form-group">
                          <input class="form-control input-lg" type="text" placeholder=".input-lg">
                        </div>

                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Default input">
                        </div>

                        <div class="form-group">
                          <input class="form-control input-sm" type="text" placeholder=".input-sm">
                        </div>

                        <div class="form-group">
                          <select class="form-control input-lg">
                            <option value="">.input-lg</option>
                          </select>
                        </div>

                        <div class="form-group">
                          <select class="form-control">
                            <option value="">Default select</option>
                          </select>
                        </div>

                        <div class="form-group">
                          <select class="form-control input-sm">
                            <option value="">.input-sm</option>
                          </select>
                        </div>
                      </form>
                    </div>
                  </div>

                </div>
                <div class="content-row">

                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <div class="panel-title"><b>Create Form</b>
                      </div>

                      <div class="panel-options">
                        <a class="bg" data-target="#sample-modal-dialog-1" data-toggle="modal" href="#sample-modal"><i class="entypo-cog"></i></a>
                        <a data-rel="collapse" href="#"><i class="entypo-down-open"></i></a>
                        <a data-rel="close" href="#!/tasks" ui-sref="Tasks"><i class="entypo-cancel"></i></a>
                      </div>
                    </div>

                    <div class="panel-body">
                      <form novalidate="" role="form" class="form-horizontal">
                        <div class="form-group">
                          <label class="col-md-2 control-label">Title</label>
                          <div class="col-md-10">
                            <input type="text" required="" placeholder="Title" id="title" class="form-control" name="title">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-2 control-label">Subject</label>
                          <div class="col-md-10">
                            <input type="text" required="" placeholder="Subject" id="subject" class="form-control" name="title">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-2 control-label" for="description">Description</label>
                          <div class="col-md-10">
                            <textarea required="" class="form-control" placeholder="Description" rows="10" cols="30" id="description" name="description"></textarea>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-md-offset-2 col-md-10">
                            <button class="btn btn-info" type="submit">Submit</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>

                </div>


                <div class="content-row">

                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <div class="panel-title"><b>Create Form</b>
                      </div>

                      <div class="panel-options">
                        <a class="bg" data-target="#sample-modal-dialog-1" data-toggle="modal" href="#sample-modal"><i class="entypo-cog"></i></a>
                        <a data-rel="collapse" href="#"><i class="entypo-down-open"></i></a>
                        <a data-rel="close" href="#!/tasks" ui-sref="Tasks"><i class="entypo-cancel"></i></a>
                      </div>
                    </div>

                    <div class="panel-body">
                      <form role="form">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Email address</label>
                          <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputPassword1">Password</label>
                          <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputFile">File input</label>
                          <input type="file" id="exampleInputFile">
                          <p class="help-block">Example block-level help text here.</p>
                        </div>
                        <div class="checkbox">
                          <label>
                            <input type="checkbox">Check me out
                          </label>
                        </div>
                        <button type="submit" class="btn btn-default">Submit</button>
                      </form>
                    </div>
                  </div>

                </div>

                <div class="content-row">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="panel panel-primary" data-collapsed="0">
                        <div class="panel-heading">
                          <div class="panel-title">
                            Input Grid
                          </div>
                          <div class="panel-options">
                            <a href="#sample-modal" data-toggle="modal" data-target="#sample-modal-dialog-1" class="bg"><i class="entypo-cog"></i></a>
                            <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                            <a href="#" data-rel="reload"><i class="entypo-arrows-ccw"></i></a>
                            <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
                          </div>
                        </div>
                        <div class="panel-body">
                          <div class="row">
                            <div class="col-md-12">
                              <input type="text" class="form-control" placeholder=".col-md-12">
                              <div class="clear"></div>
                              <br />
                            </div>

                            <div class="col-md-6">
                              <input type="text" class="form-control" placeholder=".col-md-6">
                            </div>

                            <div class="col-md-6">
                              <input type="text" class="form-control" placeholder=".col-md-6">
                              <div class="clear"></div>
                              <br />
                            </div>

                            <div class="col-md-4">
                              <input type="text" class="form-control" placeholder=".col-md-4">
                            </div>

                            <div class="col-md-4">
                              <input type="text" class="form-control" placeholder=".col-md-4">
                            </div>

                            <div class="col-md-4">
                              <input type="text" class="form-control" placeholder=".col-md-4">
                              <div class="clear"></div>
                              <br />
                            </div>

                            <div class="col-md-3">
                              <input type="text" class="form-control" placeholder=".col-md-3">
                            </div>

                            <div class="col-md-3">
                              <input type="text" class="form-control" placeholder=".col-md-3">
                            </div>

                            <div class="col-md-3">
                              <input type="text" class="form-control" placeholder=".col-md-3">
                            </div>

                            <div class="col-md-3">
                              <input type="text" class="form-control" placeholder=".col-md-3">
                              <div class="clear"></div>
                              <br />
                            </div>

                            <div class="col-md-2">
                              <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2">
                              <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2">
                              <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2">
                              <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2">
                              <input type="text" class="form-control" placeholder=".col-md-2">
                            </div>

                            <div class="col-md-2">
                              <input type="text" class="form-control" placeholder=".col-md-2">
                              <div class="clear"></div>
                              <br />
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>

                            <div class="col-md-1">
                              <input type="text" class="form-control" placeholder=".col-md-1">
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="content-row">
                  <h2 class="content-row-title">Checkboxes and Radios
                    <span>(<b>How to use</b>: https://github.com/fronteed/iCheck/)</span>
                  </h2>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="checkbox">
                            <input type="checkbox" id="flat-checkbox-1">
                            <label for="flat-checkbox-1">default</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="checkbox">
                            <input type="checkbox" id="flat-checkbox-2" checked>
                            <label for="flat-checkbox-2">checked</label>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="checkbox">
                            <input type="checkbox" id="flat-checkbox-3" disabled>
                            <label for="flat-checkbox-3">disabled</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="checkbox">
                            <input type="checkbox" id="flat-checkbox-4" checked disabled>
                            <label for="flat-checkbox-4">checked & disabled</label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="radio">
                            <input type="radio" id="flat-radio-1">
                            <label for="flat-radio-1">default</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="radio">
                            <input type="radio" id="flat-radio-2" checked>
                            <label for="flat-radio-2">checked</label>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="radio">
                            <input type="radio" id="flat-radio-3" disabled>
                            <label for="flat-radio-3">disabled</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="radio">
                            <input type="radio" id="flat-radio-4" checked disabled>
                            <label for="flat-radio-4">checked & disabled</label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="content-row">
                  <h2 class="content-row-title">Toggle
                    <span>(Used for
                      <code>checkbox</code>or
                      <code>radio</code>)</span>
                  </h2>
                  <div class="row">
                    <div class="col-md-4">
                      <label class="toggle">
                        <input type="checkbox">
                        <span class="handle"></span>
                      </label>
                    </div>
                    <div class="col-md-4">
                      <label class="toggle">
                        <input type="checkbox" checked>
                        <span class="handle"></span>
                      </label>
                    </div>
                    <div class="col-md-4">
                      <label class="toggle">
                        <input type="checkbox" disabled>
                        <span class="handle"></span>
                      </label>
                    </div>
                  </div>
                </div>

                <div class="content-row">
                  <h2 class="content-row-title">Stepper
                    <span>(<b>How to use</b>: https://github.com/benplum/Stepper)</span>
                  </h2>
                  <div class="row">
                    <div class="col-md-6">
                      <input type="number" class="form-control" />
                    </div>
                    <div class="col-md-6">
                      <input type="number" class="form-control" disabled/>
                    </div>
                  </div>
                </div>


                <div class="content-row">
                  <h2 class="content-row-title">Selecter
                    <span>(<b>How to use</b>: https://github.com/benplum/Selecter)</span>
                  </h2>
                  <div class="row">
                    <div class="col-md-3">
                      <select name="selecter_basic" class="selecter_1">
                        <optgroup label="Group One">
                          <option value="1">One</option>
                          <option value="2">Two</option>
                          <option value="3">Three</option>
                        </optgroup>
                        <optgroup label="Group One">
                          <option value="4">Four</option>
                          <option value="5">Five</option>
                          <option value="6">Six</option>
                          <option value="7">Seven</option>
                        </optgroup>
                        <optgroup label="Group Three">
                          <option value="8">Eight</option>
                          <option value="9">Nine</option>
                          <option value="10">Ten</option>
                        </optgroup>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <select name="selecter_basic" class="selecter_2" data-selecter-options='{"label":"Jump Sites","external":"true"}'>
                        <option value="http://google.com">Google Search</option>
                        <option value="http://boingboing.com">BoingBoing</option>
                        <option value="http://cnn.com">CNN News</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <select name="selecter_basic" class="selecter_3" data-selecter-options='{"cover":"true"}'>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                        <option value="4">Four</option>
                        <option value="5">Five</option>
                      </select>
                    </div>
                    <div class="col-md-3">
                      <select name="selecter_basic" class="selecter_4" disabled="disabled">
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                        <option value="4">Four</option>
                        <option value="5">Five</option>
                      </select>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <select name="selecter_multiple" class="selecter_5" multiple="multiple">
                        <option value="1">One</option>
                        <option value="2" disabled>Two</option>
                        <option value="3" selected>Three</option>
                        <option value="4">Four</option>
                        <option value="5">Five</option>
                        <option value="6">Six</option>
                        <option value="7">Seven</option>
                        <option value="8">Eight</option>
                        <option value="9">Nine</option>
                        <option value="10">Ten</option>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <select name="selecter_multiple" class="selecter_6" multiple="multiple" disabled="disabled">
                        <option value="1">One</option>
                        <option value="2" disabled>Two</option>
                        <option value="3" selected>Three</option>
                        <option value="4">Four</option>
                        <option value="5">Five</option>
                        <option value="6">Six</option>
                        <option value="7">Seven</option>
                        <option value="8">Eight</option>
                        <option value="9">Nine</option>
                        <option value="10">Ten</option>
                      </select>
                    </div>
                  </div>
                </div>


                <div class="content-row">
                  <div class="row">
                    <div class="col-md-12">
                      <h2 class="content-row-title">Forms</h2>
                      <div class="row">
                        <div class="col-md-6">
                          <input type="text" placeholder="Text input" class="form-control">
                        </div>
                        <div class="col-md-6">
                          <input type="text" placeholder="Text input" disabled="" class="form-control">
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <textarea rows="3" class="form-control"></textarea>
                        </div>
                        <div class="col-md-6">
                          <div class="row">
                            <div class="col-md-12">
                              <div class="input-group">
                                <span class="input-group-addon">$</span>
                                <input type="text" class="form-control">
                                <span class="input-group-addon">.00</span>
                              </div>
                            </div>
                            <div class="clearfix"></div>
                            <br>
                            <div class="col-md-12">
                              <div class="input-group">
                                <div class="input-group-btn">
                                  <button tabindex="-1" class="btn btn-danger" type="button">Action</button>
                                  <button tabindex="-1" data-toggle="dropdown" class="btn btn-danger dropdown-toggle" type="button">
                                                          <span class="caret"></span>
                                                        </button>
                                  <ul class="dropdown-menu">
                                    <li><a href="#">Action</a></li>
                                    <li><a href="#">Another action</a></li>
                                    <li><a href="#">Something else here</a></li>
                                    <li class="divider"></li>
                                    <li><a href="#">Separated link</a></li>
                                  </ul>
                                </div>
                                <input type="text" class="form-control">
                                <div class="input-group-btn">
                                  <button tabindex="-1" class="btn btn-primary" type="button">Action</button>
                                  <button tabindex="-1" data-toggle="dropdown" class="btn btn-primary dropdown-toggle" type="button">
                                                          <span class="caret"></span>
                                                        </button>
                                  <ul class="dropdown-menu">
                                    <li><a href="#">Action</a></li>
                                    <li><a href="#">Another action</a></li>
                                    <li><a href="#">Something else here</a></li>
                                    <li class="divider"></li>
                                    <li><a href="#">Separated link</a></li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-search search-only">
                            <i class="search-icon glyphicon glyphicon-search"></i>
                            <input type="text" class="form-control search-query">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="input-group form-search">
                            <input type="text" class="form-control search-query">
                            <span class="input-group-btn">
                              <button data-type="last" class="btn btn-primary" type="submit">Search</button>
                            </span>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-4">
                          <div class="form-group has-success has-feedback">
                            <label for="inputSuccess2" class="control-label">Input with success</label>
                            <input type="text" id="inputSuccess2" class="form-control">
                            <span class="glyphicon glyphicon-ok form-control-feedback"></span>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group has-warning has-feedback">
                            <label for="inputWarning2" class="control-label">Input with warning</label>
                            <input type="text" id="inputWarning2" class="form-control">
                            <span class="glyphicon glyphicon-warning-sign form-control-feedback"></span>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="form-group has-error has-feedback">
                            <label for="inputError2" class="control-label">Input with error</label>
                            <input type="text" id="inputError2" class="form-control">
                            <span class="glyphicon glyphicon-remove form-control-feedback"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="content-row">
                  <div class="row content-row-modal">
                    <div class="col-md-6">
                      <h2 class="content-row-title">Modals</h2>
                      <div class="modal">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                              <h4 class="modal-title">Contact</h4>
                            </div>
                            <div class="modal-body">
                              <p>Feel free to contact us for any issues you might have with our products.</p>
                              <div class="row">
                                <div class="col-xs-6">
                                  <label>Name</label>
                                  <input type="text" class="form-control" placeholder="Name">
                                </div>
                                <div class="col-xs-6">
                                  <label>Email</label>
                                  <input type="text" class="form-control" placeholder="Email">
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-xs-12">
                                  <label>Message</label>
                                  <textarea class="form-control" rows="3">Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Morbi leo risus, porta ac consectetur ac</textarea>
                                </div>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              <button type="button" class="btn btn-success">Send</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </div><!-- panel body -->
            </div>
        </div><!-- content -->
      </div>
    </div>
    <!--footer-->
    <div class="site-footer">
      <div class="container">
        <div class="download">
          <span class="download__infos">You simply have to <b>try it</b>.</span>&nbsp;&nbsp;&nbsp;&nbsp;
          <a class="btn btn-primary" href="https://github.com/silverbux/bootflat-admin/archive/master.zip">Download Bootflat-Admin</a>&nbsp;&nbsp;&nbsp;&nbsp;
            <!-- SmartAddon BEGIN -->
            <script type="text/javascript">
            (function() {
            var s=document.createElement('script');s.type='text/javascript';s.async = true;
            s.src='http://s1'+'.smartaddon.com/share_addon.js';
            var j =document.getElementsByTagName('script')[0];j.parentNode.insertBefore(s,j);
            })();
            </script>

            <a href="http://www.smartaddon.com/?share" title="Share Button" onclick="return sa_tellafriend('','bookmarks')"><img alt="Share" src="http://bootflat.github.io/img/share.gif" border="0" /></a>
            <!-- SmartAddon END -->
        </div>
        <hr class="dashed" />
        <div class="row">
          <div class="col-md-4">
            <h3>Get involved</h3>
            <p>Bootflat is hosted on <a href="https://github.com/silverbux/bootflat-admin" target="_blank" rel="external nofollow">GitHub</a> and open for everyone to contribute. Please give us some feedback and join the development!</p>
          </div>
          <div class="col-md-4">
            <h3>Contribute</h3>
            <p>You want to help us and participate in the development or the documentation? Just fork Bootflat on <a href="https://github.com/silverbux/bootflat-admin" target="_blank" rel="external nofollow">GitHub</a> and send us a pull request.</p>
          </div>
          <div class="col-md-4">
            <h3>Found a bug?</h3>
            <p>Open a <a href="https://github.com/silverbux/bootflat-admin/issues" target="_blank" rel="external nofollow">new issue</a> on GitHub. Please search for existing issues first and make sure to include all relevant information.</p>
          </div>
        </div>
        <hr class="dashed" />
        <div class="row">
          <div class="col-md-6">
            <h3>Talk to us</h3>
            <ul>
              <li>Tweet us at <a href="https://twitter.com" target="_blank">@YourTwitter</a>&nbsp;&nbsp;&nbsp;&nbsp;Email us at <span class="connect">info@yourdomain.com</span></li>
              <li>
                <a title="Twitter" href="https://twitter.com" target="_blank" rel="external nofollow"><i class="icon" data-icon="&#xe121"></i></a>
                <a title="Facebook" href="https://www.facebook.com" target="_blank" rel="external nofollow"><i class="icon" data-icon="&#xe10b"></i></a>
                <a title="Google+" href="https://plus.google.com/" target="_blank" rel="external nofollow"><i class="icon" data-icon="&#xe110"></i></a>
                <a title="Github" href="https://github.com/alexquiambao" target="_blank" rel="external nofollow"><i class="icon" data-icon="&#xe10e"></i></a>
              </li>
            </ul>
          </div>
          <div class="col-md-6">
            <!-- Begin MailChimp Signup Form -->
            <link href="//cdn-images.mailchimp.com/embedcode/slim-081711.css" rel="stylesheet" type="text/css">
            <div id="mc_embed_signup">
            <h3 style="margin-bottom: 15px;">Newsletter</h3>
            <form action="" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" novalidate>
                <input style="margin-bottom: 10px;" type="email" value="" name="EMAIL" class="email form-control" id="mce-EMAIL" placeholder="email address" required>
                <span class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="btn btn-primary"></span>
            </form>
            </div>
            <!--End mc_embed_signup-->
          </div>
        </div>
        <hr class="dashed" />
        <div class="copyright clearfix">
          <p><b>Bootflat</b>&nbsp;&nbsp;&nbsp;&nbsp;<a href="getting-started.php">Getting Started</a>&nbsp;&bull;&nbsp;<a href="index.php">Documentation</a>&nbsp;&bull;&nbsp;<a href="https://github.com/Bootflat/Bootflat.UI.Kit.PSD/archive/master.zip">Free PSD</a>&nbsp;&bull;&nbsp;<a href="colors.php">Color Picker</a></p>
          <p>Code licensed under <a href="http://opensource.org/licenses/mit-license.php" target="_blank" rel="external nofollow">MIT License</a>, documentation under <a href="http://creativecommons.org/licenses/by/3.0/" rel="external nofollow">CC BY 3.0</a>.</p>
        </div>
      </div>
    </div>
  </body>
</html>
